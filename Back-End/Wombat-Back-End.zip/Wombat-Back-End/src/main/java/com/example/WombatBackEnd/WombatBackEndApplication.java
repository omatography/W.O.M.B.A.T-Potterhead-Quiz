package com.example.WombatBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WombatBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(WombatBackEndApplication.class, args);
	}

}
